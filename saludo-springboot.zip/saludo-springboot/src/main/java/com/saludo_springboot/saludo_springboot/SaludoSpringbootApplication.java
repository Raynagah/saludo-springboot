package com.saludo_springboot.saludo_springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaludoSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaludoSpringbootApplication.class, args);
	}

}
