package com.saludo_springboot.saludo_springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludoSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
